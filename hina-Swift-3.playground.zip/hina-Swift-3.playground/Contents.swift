

import UIKit

var greeting = "Welcome to the Future of Computers!"

class Computer {
    private var brand:String
    private var processor:String
    private var year:Int
    private var ram:Int
    
    init(brand:String ,processor:String,ram:Int,year:Int){
        self.brand = brand
        self.processor = processor
        self.year = year
        self.ram = ram
    }
    func getBrand() -> String {
            return brand
        }

        func getProcessor() -> String {
            return processor
        }

        func getRam() -> Int {
            return ram
        }
    func getYear() -> Int {
        return year
    }

    func displaySpecs() {
        print("\(self.brand)\(self.processor) Year \(self.year) ram: \(self.ram)")
    }
    
}
class Laptop:Computer {
    private var isTouchscreen:Bool
    
    init(brand:String, processor: String, ram:Int,isTouchscreen:Bool, year:Int){
        self.isTouchscreen = isTouchscreen
        super.init(brand: brand, processor: processor, ram: ram, year: year)
    }
    override func displaySpecs() {
        print("\(super.getBrand()) \(super.getProcessor()) Year: \(super.getYear()) RAM: \(super.getRam())GB Touchscreen: Has a touchscreen:\(self.isTouchscreen)")
    }
    func Touchscreen() {
        if self.isTouchscreen{
            print("Thank you for saving the planet with electric.")
        } else {
            print("I'm a gas loving monster you fool!")
        }}}
    
//Desktop
class Desktop: Computer {
    private var hasDedicatedGPU: Bool
    
    init(brand: String, processor: String, ram: Int, hasDedicatedGPU: Bool, year:Int) {
        self.hasDedicatedGPU = hasDedicatedGPU
        super.init(brand: brand, processor: processor, ram: ram, year: year)
    }
    func getHasDedicatedGPU(){
        if self.hasDedicatedGPU == true{
            print("has dedicated GPU")
        }else {
            print("no GPU")
        }}}

//Server

class Server: Computer {
    private var rackUnits: Int

    init(brand: String, processor: String, ram: Int, rackUnits: Int,year:Int) {
        self.rackUnits = rackUnits
        super.init(brand: brand, processor: processor, ram: ram, year:year)
    }

    func getRackUnits() -> Int {
        return rackUnits
    }

    override func displaySpecs() {
        print("\(super.getBrand()) \(super.getProcessor()) Year: \(super.getYear()) RAM: \(super.getRam())GB) Rack Units: \(rackUnits)")
    }}
    
//Output

var myLaptop = Laptop(brand: "Apple", processor: "M1",    ram:16,isTouchscreen: false,year: 2024)
    myLaptop.displaySpecs()

var myDesktop = Desktop(brand: "Dell", processor: "Intel i7", ram: 32, hasDedicatedGPU: true, year:2023)
  myDesktop.displaySpecs()

var myServer = Server(brand: "HP", processor: "Xeon", ram: 64, rackUnits: 4, year:2024)
   myServer.displaySpecs()
